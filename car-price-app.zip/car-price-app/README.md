# 🚗 Car Price Predictor — Streamlit App

A polished Streamlit UI for the Linear / Ridge / Lasso Regression models from
your notebook (`Linear_Ridge_&_Lasso_Regression.ipynb`), used to predict a
used car's price from its brand, body type, mileage, engine, year and
registration status.

## What's in here

```
car-price-app/
├── app.py                    # the Streamlit UI (deploy this)
├── train_model.py            # reproduces the notebook, saves the model bundle
├── requirements.txt          # dependencies for the deployed app
├── requirements-train.txt    # extra deps (kagglehub) needed only for training
├── .streamlit/config.toml    # theme colors
└── README.md
```

## 1. Train the model (do this once, before deploying)

The app needs a file called `car_price_bundle.pkl` sitting next to `app.py`.
Generate it with:

```bash
pip install -r requirements-train.txt
python train_model.py
```

This downloads the same dataset the notebook used
(`smritisingh1997/car-salescsv` on Kaggle) via `kagglehub`, cleans it,
trains Linear/Ridge/Lasso, and saves a single bundle containing:

- all three fitted models
- the label encoders for Brand / Body / Engine Type / Registration
- the feature order the models expect
- R² / MAE / RMSE for each model
- min/max ranges for the numeric sliders

> **No Kaggle credentials?** Download the CSV manually from the Kaggle
> dataset page (file name: `1.04. Real-life example.csv`) and drop it into
> this folder — `train_model.py` will use it automatically instead of
> calling kagglehub.

## 2. Run it locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## 3. Deploy to Streamlit Community Cloud

1. Push this folder (including the generated `car_price_bundle.pkl`) to a
   GitHub repo.
2. Go to [share.streamlit.io](https://share.streamlit.io), click **New app**,
   point it at your repo, and set the main file to `app.py`.
3. Deploy. Streamlit Cloud will install `requirements.txt` automatically.

That's it — no `kagglehub` or training dependencies are needed at deploy
time since the model is already baked into `car_price_bundle.pkl`.

## Notes

- Predictions are computed on `log(price)` (matching the notebook) and
  exponentiated back to a dollar amount in the UI.
- The sidebar lets you switch between Linear, Ridge and Lasso and shows a
  live comparison table of each model's test-set R² / MAE / RMSE.
- Clicking **Predict price** also plots a small bar chart comparing what all
  three models would have guessed for the same car.
